// things overcome:
// window scroll position
// adding style to elements in the DOM - have to add to the DOM and then add style
// Add all methods in IIFE so as to not mess with window
// body not rendering everything and thus having to do different rounds - having to wait for render
// as well as links, need to find elements with event listeners to simulate a click

const listeners = [];
const original = EventTarget.prototype.addEventListener;
EventTarget.prototype.addEventListener = function(...args) {
	console.log('invoked');
	listeners.push({
		node: this,
		type: arguments[0]
	});
	return original.apply(this, ...args);
}

(function() {
	let round = 0;
	let maxRounds = 5;
	let roundInterval, scrollListener, mouseListener;
	const listeners = [];

	function h(type, content = '', classList) {
		const elem = document.createElement(type);
		elem.textContent = content;
		classList ? elem.classList = classList : void 0;
		return elem;
	};

	let normaliseProp = prop => Number(prop.replace('px', ''));

	const throttle = (func, limit) => {
		let inThrottle
		return function() {
			const args = arguments
			const context = this
			if (!inThrottle) {
				func.apply(context, args)
				inThrottle = true
				setTimeout(() => inThrottle = false, limit)
			}
		}
	}

	function highlightLinks() {
		[...document.querySelectorAll('.webres-injected-link')].forEach(elem => document.body.removeChild(elem));
		[...document.getElementsByTagName('a')].forEach((link, idx) => {
			const elem = h('span', '', 'webres-injected-link');
			elem.appendChild(h('p', idx + 1));
			elem.dataset.linkIndex = (idx + 1);
			elem.dataset.link = link; // by assigning <a> to dataset, implicitly pull out href
			const rect = link.getBoundingClientRect();
			const style = getComputedStyle(link);
			const padTop = normaliseProp(style.getPropertyValue('padding-top'));
			const padLeft = normaliseProp(style.getPropertyValue('padding-left'));
			const left = ((rect.x - 5) - padTop) + window.scrollX;
			const top = ((rect.y - 10) - padLeft) + window.scrollY;
			document.body.appendChild(elem);
			elem.setAttribute('style', `left:${left}px; top:${top}px; `);
		});
	}

	function clickLink(number) {
		const [elem] = document.querySelectorAll(`[data-link-index='${number}']`);
		window.location = elem.dataset.link;
	}

	function phasedHighlight() {
		if (++round === maxRounds) return clearInterval(roundInterval);
		highlightLinks();
	}

	function getAllListeners() {
		// let elements = [];
		// const allElements = document.querySelectorAll('*');
		// const types = [];
		// for (let ev in window) {
		// 	if (/^on/.test(ev)) types[types.length] = ev;
		// }
		//
		// console.log(allElements);
		//
		// allElements.forEach(currentElement => {
		// 	console.log(currentElement.onclick);
		// 	types.forEach(type => {
		// 		if (typeof currentElement[type] === 'function') {
		// 			elements.push({
		// 				"node": currentElement,
		// 				"listeners": [{
		// 					"type": types[j],
		// 					"func": currentElement[types[j]].toString(),
		// 				}]
		// 			})
		// 		}
		// 	})
		// })
		//
		// console.log(elements);
		//
		// const listeners = elements.filter(element => element.listeners.length);
		// console.log(listeners);
		console.log(listeners);
	}

	// function interceptListener(type, element){
	// 	if(typeof element[type] == "function"){
	// 		element[type] = (function(){
	// 			var original = this[type];
	// 			this.allListeners = this.allListeners || {};
	// 			return function() {
	// 				this.allListeners[arguments[0]] = arguments[0] in this.allListeners ? this.allListeners[arguments[0]] + 1 : 1;
	// 				console.log(this);
	// 				return original.apply(this, arguments);
	// 			}
	// 		}.bind(element))();
	// 	}
	// }
	//
	// interceptListener("attachEvent", window);
	// interceptListener("addEventListener", window);

	function main() {
		setTimeout(highlightLinks, 100);
		roundInterval = setInterval(phasedHighlight, 1000);
		setTimeout(getAllListeners, 100);

		scrollListener = window.addEventListener('scroll', throttle(highlightLinks, 50))
		mouseListener = window.addEventListener('mousedown', throttle(highlightLinks, 50))
	}

	main();

})();
